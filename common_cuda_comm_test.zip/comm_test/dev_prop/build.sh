nvcc -O3 cap_test.cc -o cap_test -lcuda
