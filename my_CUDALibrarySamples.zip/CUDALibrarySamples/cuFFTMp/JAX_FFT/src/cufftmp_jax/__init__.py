# -*- coding: utf-8 -*-

from .cufftmp_jax import cufftmp
